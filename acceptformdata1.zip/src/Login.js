import { useState } from "react"

export function Login(){

    const[formdata,setFormData] = useState({name:"",email:"",pass:"",phone:""})

    const ManageChange=(e)=>{
        setFormData({...formdata, [e.target.name]:e.target.value});
    }
    const Submit=()=>{
    console.log(formdata);
 }

    return(
        <div>
                <input type="text" placeholder="enter name" name="name" onChange={ManageChange}></input><br/>
                <input type="text" placeholder="enter email" name="email" onChange={ManageChange}></input><br/>
                <input type="password" placeholder="enter password" name="pass" onChange={ManageChange}></input><br/>
                <input type="text" placeholder="enter phone" name="phone" onChange={ManageChange}></input><br/>
                
                <input type="button" value="get Name" onClick={Submit}></input>
            </div>
    )
}