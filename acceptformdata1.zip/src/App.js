import { Login } from "./Login";



function App() {
  return (
    <div >
      
      <Login></Login>
    </div>
  );
}

export default App;
