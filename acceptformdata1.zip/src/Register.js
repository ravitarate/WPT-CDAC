import { Component } from "react";

export class Register extends Component
{
    constructor(){
        super();
        this.state={formdata:{name:"",email:"",pass:"",phone:""}}
        
        this.Submit=this.Submit.bind(this);
        this.ManageChange=this.ManageChange.bind(this);
    }
        

    ManageChange(e){
        
        this.setState({formdata:{...this.state.formdata, [e.target.name]:e.target.value}})
    }
    Submit(){
        console.log(this.state.formdata);
    }

    render(){
        return(

             <div>
                <input type="text" placeholder="enter name" name="name" onChange={this.ManageChange}></input><br/>
                <input type="text" placeholder="enter email" name="email" onChange={this.ManageChange}></input><br/>
                <input type="password" placeholder="enter password" name="pass" onChange={this.ManageChange}></input><br/>
                <input type="text" placeholder="enter phone" name="phone" onChange={this.ManageChange}></input><br/>
                
                <input type="button" value="get Name" onClick={this.Submit}></input>
            </div>
        )
    }
}