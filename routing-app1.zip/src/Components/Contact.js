export function Contact() {

    return(
        <div>
            <h3>Hello this is Contact Section</h3>
        </div>
    )
}