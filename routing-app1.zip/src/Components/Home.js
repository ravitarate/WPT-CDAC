
export function Home() {

    return(
        <div>
            <h3>Hello this is Home Section</h3>
        </div>
    )
}