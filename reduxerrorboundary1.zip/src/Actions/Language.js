export function ChangeLanguage(){
    return {type:'CHANGE_LANGUAGE'}
}