export function IncrementScore(){
    return {type:'increment'}
}

export function DecrementScore(){
    return {type:'decrement'}

}