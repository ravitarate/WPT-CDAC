
export function Cnt() {

    return(
        <div>
            <h1>Contact Us</h1>
            <p>Search for the keywords to learn more about each warning.</p>
        </div>
    )
    

}