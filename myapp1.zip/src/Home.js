import { Component } from "react";
import {Header} from './Header';

export class Home extends Component{
    render(){
        return(
            <div>
                <Header title="This is Home" description = "this is description"/>
                <h1>Hello,Welcome</h1>
            </div>
        );
    }
}