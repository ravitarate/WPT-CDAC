import { Component } from "react";

export class ScoreCard extends Component{

    constructor(){
        super();
        this.state={marks : 95, subject : "React"}
        this.AddMarks=this.AddMarks.bind(this);
        this.ReduceMarks=this.ReduceMarks.bind(this);
     
    }

    AddMarks(){
        this.setState({marks:this.state.marks+1});
    }
    ReduceMarks(){
         this.setState({marks:this.state.marks-1});
    }

    render(){
        return(
            <div>
                <h1>{this.state.marks} - {this.state.subject}</h1>
                <button onClick={this.AddMarks}>+</button>
                <button onClick={this.ReduceMarks}>-</button>
                <p> Pass</p>
            </div>
        )
    }
}