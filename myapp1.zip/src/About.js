import { Component } from "react";

export class About extends Component{
    render(){
        return(
            <div>
                <h3>This is an About Section</h3>
            </div>
        );
    }
}