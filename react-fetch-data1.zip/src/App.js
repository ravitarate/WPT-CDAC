
import './App.css';
import { DataFetch } from './DataFetch';
import { UserData } from './UserData';



function App() {
  return (
    <div>
    <UserData> </UserData>
    <DataFetch></DataFetch>
    </div>
  );
}

export default App;
